import React, { Component }from 'react';
// import Card from "./movie/Card";


class DiscoverBattle extends Component {
   render() {
    return (
      <div className="row">
        
      </div>
    );
  }
}

export default DiscoverBattle;
