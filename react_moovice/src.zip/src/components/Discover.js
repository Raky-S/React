import React, { Component }from 'react';

class Discover extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}

export default Discover;
