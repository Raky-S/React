import React, { Component }from 'react';

class MyList extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}

export default MyList;
